package Trolls;

public interface Troll {
    // Method to give instructions
    String giveInstructions();

    // Method to play the game
    boolean playGame();
}
